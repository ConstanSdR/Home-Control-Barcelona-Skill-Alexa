# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils
import urllib.request
import requests

from requests.auth import HTTPBasicAuth

from random import randint, uniform,random

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


#******** MENSAJES PREDEFINIDOS ********
WELCOME_MESSAGE= "Hola. Bienvenido al Sistema de Control de Casa. Qué quieres hacer?"
DEVICE_ON_A_MESSAGE= "He encendido la {device}. Quiéres hacer algo más?"
DEVICE_ON_B_MESSAGE= "He encendido el {device}. Algo más?"
DEVICE_OFF_A_MESSAGE= "He apagado la {device}. Quiéres hacer algo más?"
DEVICE_OFF_B_MESSAGE= "He apagado el {device}. Algo más?"
CANCEL_MESSAGE= "Hasta luego!"
END_MESSAGE= "Sigo sin entenderte. Cerrando sistema de control de voz"
#***************************************


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hola. Qué quieres hacer?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class FallbackIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("FallbackIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Esta orden no está dentro de las opciones. Dime otra por favor"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class DispositivosIntentHandler(AbstractRequestHandler):
    """Ordenes y Dispositivos"""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("DispositivosIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        slots = handler_input.request_envelope.request.intent.slots
        
        speak_output= "Entrando en intent Dispositivos"
        Orden = slots["order"].value
        Dispositivo = slots["device"].value
        #Path = "http://sdrmhome.dns05.com:1880/voz?Accion="                                            # DDNS ChangeIp
        #Path = "http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion="               # DDNS NoIp
        #Path = "http://sdrmhome.ddns.net:1880/alexa?Accion="                                            # DDNS NoIp
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=" 
                
        Orden_Path ={
                    "encender": "encender",
                    "enciende": "encender",
                    "desconecta": "apagar",
                    "pon": "encender",
                    "activa": "encender",
                    "apaga": "apagar",
                    "apagar": "apagar",
                    "reproducir": "reproducir",
                    "quita": "apagar",
                    "desactiva": "apagar"
                    #"encender": "encender",
                    #"enciende": "encender",
                    #"desconecta": "apagar",
                    #"pon": "poner",
                    #"activa": "poner",
                    #"apaga": "apagar",
                    #"apagar": "apagar",
                    #"reproducir": "reproducir",
                    #"quita": "quitar",
                    #"desactiva": "quitar"
                    }
                    
        Dispositivo_Path={
                    "enchufe de elsa": "enchufe_Elsa",
                    "pc de elsa": "pc_Elsa",
                    "ordenador de elsa": "pc_Elsa",
                    "pc": "pc_Elsa",
                    "ordenador": "pc_Elsa",
                    "calentador del baño": "calentador_baño",
                    "luz roja": "luz_roja",
                    "luz de elsa": "luz_Elsa",
                    "todo el comedor": "todo_comedor",
                    "comedor": "comedor",
                    "aire": "aire",
                    "toda la cocina": "toda_cocina",
                    "cocina": "cocina",
                    "encimera": "encimera",
                    "pasillo": "pasillo",
                    "pared": "pared",
                    "torre": "torre",
                    "terraza": "terraza",
                    "cámara": "camara",
                    "televisión": "television",
                    "television": "television",
                    "nintendo": "television",
                    "toda la casa": "todo",
                    "todo": "todo",
                    "casa": "todo",
                    "todo el salón": "todo_salon",
                    "todo salón": "todo_salon",
                    "salón": "salon",
                    "riego": "riego",
                    "riega": "riego",
                    "riega las plantas": "riego",
                    "modo cine": "modo_cine",
                    "modo tarde": "modo_tarde",
                    "modo noche": "modo_noche",
                    "modo cena": "modo_cena",
                    "modo dormir": "modo_dormir",
                    "modo comida": "modo_comida",
                    "modo desayuno": "modo_desayuno",
                    "aire a 22°": "22_grados",
                    "aire a 22": "22_grados",
                    "aire a 23°": "23_grados",
                    "aire a 23": "23_grados",
                    "aire a 24°": "24_grados",
                    "aire a 24": "24_grados",
                    "luz principal": "luz_Principal",
                    "luz de todas las habitaciones": "luz_Habitaciones",
                    "todas las habitaciones": "luz_Habitaciones",
                    "las habitaciones": "luz_Habitaciones"
        }
                    
        #****** GET HTTP ******        
        Path = Path + Orden_Path[Orden] + "%20" + Dispositivo_Path[Dispositivo]
        #Path = "http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.dns05.com:1880/voz?Accion=encender%20torre"
        #fp = urllib.request.urlopen(Path)
        
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))
        Final_Mensaje = {
                        1: " Quieres hacer algo más?",
                        2: " Necesitas algo más?",
                        3: " Algo más?",
                        4: " Deseas algo más?",
                        5: " Hago algo más?",
                        6: " Hecho. Algo más?",
                        7: " Listo. Algo más?",
                        8: " Quieres algo más?"
                        } 
        
        opcion = randint(1,8)                 
        #speak_output= Accion_Mensaje[Orden] + Dispositivo_Mensaje[Dispositivo] + Final_Mensaje[opcion]
        speak_output = Final_Mensaje[opcion]
        
        return (
            handler_input.response_builder
            .speak(speak_output)
            .ask("Dime algo si quieres mantener abierta la sesión")
            .response
        )   


class TemperaturaIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("TemperaturaIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        #fp = urllib.request.urlopen("http://sdrmhome.dns04.com:1880/voz?Accion=temperatura%20interior")   # DDNS ChangeIp
        #fp = urllib.request.urlopen("http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion=temperatura%20interior")     # DDNS NoIp
        #mybytes = fp.text
        #speak_output = mybytes.decode("utf8") + ". Quieres saber o hacer algo más?"
        #fp.close()
        
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=temperatura%20interior"
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))
        speak_output =fp.text + ". Quieres saber o hacer algo más?"
        
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("Dime algo si quieres mantener abierta la sesión 2")
                .response
        )

class YeelightIntentHandler(AbstractRequestHandler):
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("YeelightIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        slots = handler_input.request_envelope.request.intent.slots
        
        speak_output= "Entrando en intent Yeelight"
        Dispositivo = slots["device"].value
        Característica = slots["feature"].value
        Valor = str(slots["value"].value)
        #Valor = str(23);
        
        
        #Path = "http://sdrmhome.dns05.com:1880/voz?Accion="                                            # DDNS ChangeIp
        #Path = "http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion="               # DDNS NoIp
        #Path = "http://sdrmhome.ddns.net:1880/alexa?Accion="                                            # DDNS NoIp
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=" 
        
        Característica_Path ={
                    "brillo": "brillo",
                    "calidez": "calidez"
                    }
                    
        Dispositivo_Path={
                    "luz de pablo": "luz_Pablo",
                    "luz principal": "luz_Principal"
        }
                    
        #****** GET HTTP ******        
        Path = Path + Característica_Path[Característica] + "%20" + Dispositivo_Path[Dispositivo] + "%20" + Valor
        #Path = "http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.dns05.com:1880/voz?Accion=encender%20torre"
        #fp = urllib.request.urlopen(Path)
        
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))

        Final_Mensaje = {
                        1: " Quieres hacer algo más?",
                        2: " Necesitas algo más?",
                        3: " Algo más?",
                        4: " Deseas algo más?",
                        5: " Hago algo más?",
                        6: " Hecho. Algo más?",
                        7: " Listo. Algo más?",
                        8: " Quieres algo más?"
                        } 
        
        opcion = randint(1,8)                 
        #speak_output= Accion_Mensaje[Orden] + Dispositivo_Mensaje[Dispositivo] + Final_Mensaje[opcion]
        speak_output = Final_Mensaje[opcion]
        
        return (
            handler_input.response_builder
            .speak(speak_output)
            .ask("Dime algo si quieres mantener abierta la sesión")
            .response
        )   


class TemperaturaExtIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("TemperaturaExtIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        #fp = urllib.request.urlopen("http://sdrmhome.dns04.com:1880/voz?Accion=temperatura%20exterior")    #DDNS ChangeIp
        #fp = urllib.request.urlopen("http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion=temperatura%20exterior")      #DDNS NoIp
        #mybytes = fp.read()
        #speak_output = mybytes.decode("utf8") + ". Quieres saber o hacer algo más?"
        #fp.close()
        
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=temperatura%20exterior"
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))
        speak_output =fp.text + ". Quieres saber o hacer algo más?"
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("Dime algo si quieres mantener abierta la sesión 3")
                .response
        )


class DepositoIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("DepositoIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        #fp = urllib.request.urlopen("http://sdrmhome.dns04.com:1880/voz?Accion=volumen%20deposito")   #DDNS ChangeIP
        #fp = urllib.request.urlopen("http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion=volumen%20deposito")     #DDNS NoIP
        #mybytes = fp.read()
        #speak_output = mybytes.decode("utf8") + ". Deseas algo más?"
        #fp.close()
        
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=volumen%20deposito"
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))
        speak_output =fp.text + ". Quieres saber o hacer algo más?"
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("Dime algo si quieres mantener abierta la sesión 4")
                .response
        )

class EnCasaIntentHandler(AbstractRequestHandler):
    
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("EnCasaIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        
        #fp = urllib.request.urlopen("http://sdrmhome.dns04.com:1880/voz?Accion=En%20Casa")   #ChangeIP
        #fp = urllib.request.urlopen("http://ConstanSdR72:YokaiWatchRasp18@sdrmhome.ddns.net:1880/voz?Accion=En%20Casa")     #NoIP
        #mybytes = fp.read()
        #speak_output = mybytes.decode("utf8") + " ¿Deseas algo más?"
        #fp.close()
        
        Path = "http://sdrmhome.ddns.net:1880/alexa?Accion=En%20Casa"
        fp = requests.get (Path, auth = HTTPBasicAuth ('ConstanSdR72', 'YokaiWatchRasp18' ))
        speak_output =fp.text + ". Quieres saber o hacer algo más?"
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask("Dime algo si quieres mantener abierta la sesión")
                .response
        )

class ConstanIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ConstanIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        #speak_output = 'Espero 3 segundos <break time="3s"/> Buuuu!'
        #speak_output = '<speak><say-as interpret-as="interjection">Pues no.</say-as> Tú eres el más simpático y el más listo perooo ... <amazon:effect name="whispered">Ruyhé Marimón es el SexSimbol de Barcelona.....</amazon:effect> Quieres saber o hacer algo más?</speak>'
        #speak_output = '<speak>Que no se dice masaje. Se dice MAJASE. MAAA JAAA  SEEE. Si Quieres un majase .... pon la pasta encima de la mesa a ver quién se ofrece. <amazon:effect name="whispered"> Porque yo ...... paaasooo !!</amazon:effect> </speak>'
        #speak_output = '<speak>Hola Pablo. Feliz Cumpleañooooos La respuesta eeeeees ..... Hace frío en casa. ¿No?</speak>'
        return (
            handler_input.response_builder
                #amazon.effect.name=whispered

                .speak(speak_output)
                #.ask("Dime algo si quieres mantener abierta la sesión")
                .response
        )

class MasajeIntentHandler(AbstractRequestHandler):
    """Handler for Chorrada Majase."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("MasajeIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        #speak_output = 'Espero 3 segundos <break time="3s"/> Buuuu!'
        #speak_output = '<speak>Que no se dice masaje. Se dice MAJASE. MAAA JAAA  SEEE. Si Quieres un majase .... pon la pasta encima de la mesa a ver quién se ofrece. <amazon:effect name="whispered"> Porque yo ...... paaasooo !!</amazon:effect> </speak>'
        speak_output = '<speak>Hola ELSA. Feliz Cumpleaños! Acabas de decir la clave correcta. SASESÍSOSU. Ya tienes el punto número 5. Enhorabuena!</speak>'
        return (
            handler_input.response_builder
                #amazon.effect.name=whispered

                .speak(speak_output)
                .ask("Dime algo si quieres mantener abierta la sesión")
                .response
        )

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hasta luego!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )

class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Disculpa. Tengo un problema para interpretar qué quieres. Inténtalo de nuevo!!" #"Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(FallbackIntentHandler())

sb.add_request_handler(DispositivosIntentHandler())
sb.add_request_handler(TemperaturaIntentHandler())
sb.add_request_handler(YeelightIntentHandler())
sb.add_request_handler(TemperaturaExtIntentHandler())
sb.add_request_handler(DepositoIntentHandler())
sb.add_request_handler(ConstanIntentHandler())
sb.add_request_handler(EnCasaIntentHandler())
sb.add_request_handler(MasajeIntentHandler())

sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
#sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()